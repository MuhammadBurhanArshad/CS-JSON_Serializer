﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace ConsoleApp2
{
        public class LineItem
        {
            [JsonProperty("Document_Type", NullValueHandling = NullValueHandling.Ignore)]
            public string DocumentType { get; set; }

            [JsonProperty("Type", NullValueHandling = NullValueHandling.Ignore)]
            public string Type { get; set; }

            [JsonProperty("No", NullValueHandling = NullValueHandling.Ignore)]
            public string No { get; set; }

            [JsonProperty("Description", NullValueHandling = NullValueHandling.Ignore)]
            public string Description { get; set; }

            [JsonProperty("Quantity", NullValueHandling = NullValueHandling.Ignore)]
            public int? Quantity { get; set; }
        }

        public class Root
        {
            [JsonProperty("Document_Type", NullValueHandling = NullValueHandling.Ignore)]
            public string DocumentType { get; set; }

            [JsonProperty("Ship_to_Name", NullValueHandling = NullValueHandling.Ignore)]
            public string ShipToName { get; set; }

            [JsonProperty("No", NullValueHandling = NullValueHandling.Ignore)]
            public string No { get; set; }

            [JsonProperty("Sell_to_Customer_No", NullValueHandling = NullValueHandling.Ignore)]
            public string SellToCustomerNo { get; set; }

            [JsonProperty("Sell_to_Customer_Name", NullValueHandling = NullValueHandling.Ignore)]
            public string SellToCustomerName { get; set; }

            [JsonProperty("Sell_to_E_Mail", NullValueHandling = NullValueHandling.Ignore)]
            public string SellToEMail { get; set; }

            [JsonProperty("Status", NullValueHandling = NullValueHandling.Ignore)]
            public string Status { get; set; }

            [JsonProperty("Payment_Discount_Percent", NullValueHandling = NullValueHandling.Ignore)]
            public int? PaymentDiscountPercent { get; set; }

            [JsonProperty("ShippingOptions", NullValueHandling = NullValueHandling.Ignore)]
            public string ShippingOptions { get; set; }

            [JsonProperty("Ship_to_Address", NullValueHandling = NullValueHandling.Ignore)]
            public string ShipToAddress { get; set; }

            [JsonProperty("Ship_to_Address_2", NullValueHandling = NullValueHandling.Ignore)]
            public string ShipToAddress2 { get; set; }

            [JsonProperty("Ship_to_City", NullValueHandling = NullValueHandling.Ignore)]
            public string ShipToCity { get; set; }

            [JsonProperty("Ship_to_County", NullValueHandling = NullValueHandling.Ignore)]
            public string ShipToCounty { get; set; }

            [JsonProperty("Ship_to_Post_Code", NullValueHandling = NullValueHandling.Ignore)]
            public string ShipToPostCode { get; set; }

            [JsonProperty("Ship_to_Country_Region_Code", NullValueHandling = NullValueHandling.Ignore)]
            public string ShipToCountryRegionCode { get; set; }

            [JsonProperty("BillToOptions", NullValueHandling = NullValueHandling.Ignore)]
            public string BillToOptions { get; set; }

            [JsonProperty("Bill_to_Name", NullValueHandling = NullValueHandling.Ignore)]
            public string BillToName { get; set; }

            [JsonProperty("Bill_to_Address", NullValueHandling = NullValueHandling.Ignore)]
            public string BillToAddress { get; set; }

            [JsonProperty("Bill_to_Address_2", NullValueHandling = NullValueHandling.Ignore)]
            public string BillToAddress2 { get; set; }

            [JsonProperty("Bill_to_City", NullValueHandling = NullValueHandling.Ignore)]
            public string BillToCity { get; set; }

            [JsonProperty("Bill_to_County", NullValueHandling = NullValueHandling.Ignore)]
            public string BillToCounty { get; set; }

            [JsonProperty("Bill_to_Post_Code", NullValueHandling = NullValueHandling.Ignore)]
            public string BillToPostCode { get; set; }

            [JsonProperty("Bill_to_Country_Region_Code", NullValueHandling = NullValueHandling.Ignore)]
            public string BillToCountryRegionCode { get; set; }

            [JsonProperty("lineItems", NullValueHandling = NullValueHandling.Ignore)]
            public List<LineItem> LineItems { get; set; }
        }
}
