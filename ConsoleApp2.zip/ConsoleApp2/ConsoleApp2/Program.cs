﻿
using System.Text.Json;
using System.Text.Json.Nodes;
using ConsoleApp2;
using Newtonsoft.Json;

static void main(){
    Console.WriteLine("Hellow World");

    var json = "{\r\n    \"Document_Type\": \"Order\",\r\n    \"Ship_to_Name\": \"Muhammadl\",\r\n    \"No\": \"testdani2\",\r\n    \"Sell_to_Customer_No\": \"18\",\r\n    //   \"Sell_to_Customer_Name\": \"Maxy Testusery\",\r\n    // \"Sell_to_E_Mail\": \"testy@example.com\",\r\n    \"Status\": \"Open\",\r\n    \"Payment_Discount_Percent\": 0,\r\n    \"ShippingOptions\": \"Custom Address\",\r\n    \"Ship_to_Address\": \"M\",\r\n    \"Ship_to_Address_2\": \"Ln1\",\r\n    \"Ship_to_City\": \"Kennesaw\",\r\n    \"Ship_to_County\": \"Georgia\",\r\n    \"Ship_to_Post_Code\": \"12345\",\r\n    \"Ship_to_Country_Region_Code\": \"US\",\r\n    \"BillToOptions\": \"Custom Address\",\r\n    \"Bill_to_Name\": \"Muhammad\",\r\n    \"Bill_to_Address\": \"M\",\r\n    \"Bill_to_Address_2\": \"Ln1\",\r\n    \"Bill_to_City\": \"Kennesaw\",\r\n    \"Bill_to_County\": \"Georgia\",\r\n    \"Bill_to_Post_Code\": \"12345\",\r\n    \"Bill_to_Country_Region_Code\": \"US\",\r\n    \"lineItems\": [\r\n        {\r\n            \"Document_Type\": \"Order\",\r\n            \"Type\": \"Item\",\r\n            \"No\": \"SW103851\",\r\n            \"Description\": \"Torque Set\",\r\n            \"Quantity\": 1,\r\n        }\r\n    ]\r\n}";

    //Root order = JsonSerializer.Deserialize<Root>(json);
    Root order = JsonConvert.DeserializeObject<Root>(json);
    var order2 = JsonConvert.SerializeObject<Root>(order);

    var a = 1;

}